# TEMA 4 - HTTP Client

## Introducere

In acest proiect am implementat un client HTTP care comunica prin cereri cu un server de biblioteca online. Pentru usurinta implementarii am folosit limbajul C++ cu biblioteca de JSON **Nlohmann**, inclusa in proiect. Functionalitatile de POO ale limbajului au facut bilbioteca respectiva o decizie buna pentru constructia obiectelor JSON, mai ales ca documentatia a fost ampla si bine explicata.

Programul citeste de la tastatura, pana la intalnirea sirului 'exit' comenzi cu care va comunica cu server-ul. Comenzile sunt wrappere peste cereri HTTP de tip GET, POST si DELETE, care parseaza anumite date in functie de intrari si iesiri.

### DISCLAIMER: Codul de baza a fost implementarea laboratorului 9 oferita de echipa de PCOM pe canalul de Teams.

## Comenzi

- **Register**: Permite inregistrarea unui cont nou in server. Acesta citeste de la tastatura un username si o parola care sunt **verificate sa nu contina spatii**. Daca credentialele sunt bune, sunt adaugate intr-un obiect JSON care este trimis la server printr-o cerere de tip **POST**. Raspunsul este parsat si verificat de erori, altfel contul ramane inregistrat si se confirma in terminal.

- **Login**: Permite citirea unui username si parola **care nu contine spatii**. In cazul credentialelor bune, sunt impachetate in obiect JSON si trimise la server printr-o cerere **POST**. Din raspuns, trebuie extras o cheie de autentificare pentru biblioteca. Pe baza ei se valideaza faptul ca un user este logat.

- **Enter_library**: Trimite o cerere de tip **GET** in care este pus ca token cheia de acces. In caz afirmativ, server-ul va trimite un token JWT prin care se va permite utilizatorului sa interactioneze direct cu biblioteca.

- **Get_books**: Pe baza cheii de acces si a token-ului JWT, este trimisa o cerere **GET** catre server care returneaza in format JSON o lista cu toate cartile din biblioteca utilizatorului respectiv.

- **Get_book**: Preia ca input un ID de carte si printr-o cerere de tip **GET** impreuna cu cheie si token, cere server-ului o carte specifica din biblioteca. In cazul in care cartea nu exista, este afisata o eroare.

- **Add_book**: Citeste detalii (titlu, autor, editura, numar de pagini si gen) pentru o carte si le adauga intr-un JSON ce este trimis server-ului printr-o cerere **POST** pentru a adauga cartea in biblioteca personala. Pentru a functiona este nevoie de cheie, token, dar si datele sunt verificate (fara campuri lipsa sau numar de pagini nenumeric).

- **Delete_book**: Are functionalitatea asemanatoare cu functia *get_book*, citind un ID de la tastatura, dar foloseste o cerere de tip **DELETE**, prin care este stearsa cartea din biblioteca. Utilizatorul primeste un mesaj pe baza statusului de sters al cartii.

- **Logout**: Trimite o cerere de tip **GET** prin care utilizatorul actual este delogat din sesiune. Pentru a asigura securitatea, cheia si token-ul utilizatorului este sters din memorie. *Nota*: pentru ca un utilizator sa fie delogat, trebuie sa fi fost logat intai, deci sa aiba o cheie de acces existenta in sistem.

## Structura

Clientul se desfasoara in prim-plan in fisierul **client.cpp**, unde se gaseste implementarea efectiva a comenzilor si bucla de citire.

- **helpers.cpp** - fisier cu functii pentru parsarea si constructia sirurilor de caractere din cereri.
- **requests.cpp** - implementarea cererilor POST, GET si DELETE.
- **buffer.cpp** - implementare a buffer-elor pentru cereri.
- **Nlohmann si json** - Neadaugate datorita marimii. Disponibil pe Github
- **checker/checker.py** - checker-ul temei.
- **Makefile**
- **README.md** 
- **Fisiere .h aferente**